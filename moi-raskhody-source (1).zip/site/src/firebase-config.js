// Вставьте сюда конфигурацию вашего проекта Firebase.
// Firebase Console → Настройки проекта (шестерёнка) → Общие →
// прокрутите вниз до "Ваши приложения" → выберите веб-приложение → SDK setup and configuration → Config

export const firebaseConfig = {
  apiKey: "AIzaSyCt39gO-erm2Q-XUcuDy4m2Xb3o1v5Do6o",
  authDomain: "moi-raskhody.firebaseapp.com",
  projectId: "moi-raskhody",
  storageBucket: "moi-raskhody.firebasestorage.app",
  messagingSenderId: "1008154175474",
  appId: "1:1008154175474:web:b4c89c5a558067638bad6b",
};
