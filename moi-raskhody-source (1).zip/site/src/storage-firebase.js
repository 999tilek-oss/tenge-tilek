import { doc, getDoc, setDoc, deleteDoc, collection, getDocs } from 'firebase/firestore';
import { auth, db } from './firebase.js';

// Реализует тот же интерфейс window.storage, что и артефакты Claude,
// но хранит данные в Firestore, привязанные к вошедшему пользователю (auth.currentUser.uid).
// Благодаря этому одни и те же данные видны на любом устройстве, где выполнен вход
// с тем же email и паролем.

function requireUid() {
  const uid = auth.currentUser && auth.currentUser.uid;
  if (!uid) {
    throw new Error('Не выполнен вход. Сначала войдите в аккаунт.');
  }
  return uid;
}

function docRef(key, shared) {
  const uid = requireUid();
  // shared=true пока не используется этим приложением, но оставлено для совместимости API.
  const collectionPath = shared ? `shared/${uid}/data` : `users/${uid}/data`;
  return doc(db, collectionPath, key);
}

window.storage = {
  async get(key, shared = false) {
    const ref = docRef(key, shared);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      throw new Error(`Key not found: ${key}`);
    }
    return { key, value: snap.data().value, shared };
  },

  async set(key, value, shared = false) {
    const ref = docRef(key, shared);
    await setDoc(ref, { value });
    return { key, value, shared };
  },

  async delete(key, shared = false) {
    const ref = docRef(key, shared);
    const snap = await getDoc(ref);
    const existed = snap.exists();
    await deleteDoc(ref);
    return { key, deleted: existed, shared };
  },

  async list(prefix = '', shared = false) {
    const uid = requireUid();
    const collectionPath = shared ? `shared/${uid}/data` : `users/${uid}/data`;
    const snap = await getDocs(collection(db, collectionPath));
    const keys = [];
    snap.forEach(d => {
      if (d.id.startsWith(prefix)) keys.push(d.id);
    });
    return { keys, prefix, shared };
  },
};
