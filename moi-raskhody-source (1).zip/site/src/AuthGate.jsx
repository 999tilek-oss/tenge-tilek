import React, { useState, useEffect } from 'react';
import { watchAuth, signIn, signUp, signOut } from './firebase.js';

const styles = {
  wrap: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#1B211E',
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    padding: 20,
    boxSizing: 'border-box',
  },
  card: {
    width: '100%',
    maxWidth: 360,
    background: '#232A26',
    border: '1px solid #37403B',
    borderRadius: 16,
    padding: 28,
    boxSizing: 'border-box',
  },
  title: { fontSize: 22, fontWeight: 700, color: '#EDEAE0', marginBottom: 4 },
  subtitle: { fontSize: 13, color: '#9BA69C', marginBottom: 22, lineHeight: 1.5 },
  label: { display: 'block', fontSize: 11, color: '#9BA69C', marginBottom: 6, marginTop: 14, textTransform: 'uppercase', letterSpacing: '0.06em' },
  input: {
    width: '100%',
    background: '#1B211E',
    border: '1px solid #37403B',
    borderRadius: 10,
    padding: '11px 12px',
    color: '#EDEAE0',
    fontSize: 15,
    boxSizing: 'border-box',
    outline: 'none',
  },
  button: {
    width: '100%',
    marginTop: 22,
    padding: '13px 0',
    borderRadius: 11,
    background: '#D9C87A',
    border: 'none',
    color: '#1B211E',
    fontSize: 15,
    fontWeight: 600,
    cursor: 'pointer',
  },
  switchRow: { marginTop: 16, textAlign: 'center', fontSize: 13, color: '#9BA69C' },
  switchLink: { color: '#D9C87A', cursor: 'pointer', fontWeight: 600 },
  error: { marginTop: 14, fontSize: 13, color: '#D9776B', lineHeight: 1.4 },
  loading: { color: '#9BA69C', fontFamily: "-apple-system, sans-serif" },
  topBar: {
    position: 'fixed', top: 12, right: 12, zIndex: 100,
  },
  signOutBtn: {
    background: '#232A26', border: '1px solid #37403B', color: '#9BA69C',
    borderRadius: 8, padding: '6px 12px', fontSize: 12, cursor: 'pointer',
  },
};

function friendlyError(code) {
  const map = {
    'auth/invalid-email': 'Некорректный email.',
    'auth/user-not-found': 'Аккаунт с таким email не найден. Нажмите «Создать аккаунт».',
    'auth/wrong-password': 'Неверный пароль.',
    'auth/invalid-credential': 'Неверный email или пароль.',
    'auth/email-already-in-use': 'Этот email уже зарегистрирован. Нажмите «Войти».',
    'auth/weak-password': 'Пароль должен быть не короче 6 символов.',
    'auth/network-request-failed': 'Нет соединения с сетью.',
  };
  return map[code] || 'Что-то пошло не так. Попробуйте ещё раз.';
}

export default function AuthGate({ children }) {
  const [status, setStatus] = useState('loading'); // loading | signedOut | signedIn
  const [user, setUser] = useState(null);
  const [mode, setMode] = useState('signin'); // signin | signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const unsub = watchAuth(u => {
      setUser(u);
      setStatus(u ? 'signedIn' : 'signedOut');
    });
    return unsub;
  }, []);

  const submit = async () => {
    setError('');
    if (!email || !password) {
      setError('Заполните email и пароль.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'signin') {
        await signIn(email, password);
      } else {
        await signUp(email, password);
      }
    } catch (e) {
      setError(friendlyError(e.code));
    } finally {
      setBusy(false);
    }
  };

  if (status === 'loading') {
    return (
      <div style={styles.wrap}>
        <div style={styles.loading}>Загрузка…</div>
      </div>
    );
  }

  if (status === 'signedIn') {
    return (
      <>
        <div style={styles.topBar}>
          <button style={styles.signOutBtn} onClick={() => signOut()}>
            Выйти ({user.email})
          </button>
        </div>
        {children}
      </>
    );
  }

  return (
    <div style={styles.wrap}>
      <div style={styles.card}>
        <div style={styles.title}>Мои расходы</div>
        <div style={styles.subtitle}>
          {mode === 'signin'
            ? 'Войдите, чтобы увидеть свои данные на этом устройстве.'
            : 'Создайте аккаунт — данные будут доступны на любом устройстве.'}
        </div>

        <label style={styles.label}>Email</label>
        <input
          style={styles.input}
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="you@example.com"
          autoComplete="email"
        />

        <label style={styles.label}>Пароль</label>
        <input
          style={styles.input}
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          placeholder="Минимум 6 символов"
          autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
          onKeyDown={e => { if (e.key === 'Enter') submit(); }}
        />

        <button style={{ ...styles.button, opacity: busy ? 0.6 : 1 }} onClick={submit} disabled={busy}>
          {busy ? 'Подождите…' : mode === 'signin' ? 'Войти' : 'Создать аккаунт'}
        </button>

        {error && <div style={styles.error}>{error}</div>}

        <div style={styles.switchRow}>
          {mode === 'signin' ? (
            <>Нет аккаунта? <span style={styles.switchLink} onClick={() => { setMode('signup'); setError(''); }}>Создать</span></>
          ) : (
            <>Уже есть аккаунт? <span style={styles.switchLink} onClick={() => { setMode('signin'); setError(''); }}>Войти</span></>
          )}
        </div>
      </div>
    </div>
  );
}
