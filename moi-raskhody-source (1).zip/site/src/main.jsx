import './storage-firebase.js';
import React from 'react';
import ReactDOM from 'react-dom/client';
import AuthGate from './AuthGate.jsx';
import ExpenseTracker from './App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthGate>
      <ExpenseTracker />
    </AuthGate>
  </React.StrictMode>
);
