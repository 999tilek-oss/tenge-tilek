# Мои расходы

Личный трекер расходов на React + Firebase.

## Деплой на Netlify

1. Залейте эту папку в новый репозиторий на GitHub
2. На netlify.com: Add new site → Import an existing project → выберите репозиторий
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy

Netlify сам установит зависимости и соберёт сайт.
